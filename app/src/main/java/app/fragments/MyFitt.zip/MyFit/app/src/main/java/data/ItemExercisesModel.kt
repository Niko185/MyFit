package data

import android.widget.CheckBox

data class ItemExercisesModel(
    var nameExercises: String,
    var timeExercises: String,
    var checkBoxDone: Boolean,
    var gifExercises: String
)

