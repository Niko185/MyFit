package data

data class ItemDayModel(
    var cellWithKitExercises: String,
    var dayNumber: Int,
    var positionChekBox: Boolean,
)

